
const motivationText = document.getElementById('motivation-text');
const investBtn = document.getElementById('invest-btn');
const amountInput = document.getElementById('amount');
const confirmInvestBtn = document.getElementById('confirm-invest-btn');
const investmentResult = document.getElementById('investment-result');

motivationText.textContent = "Investing in our site is a great opportunity to grow your wealth. With our high returns and low risk, you can't go wrong!";

investBtn.addEventListener('click', () => {
    investBtn.style.display = 'none';
    amountInput.parentElement.style.display = 'block';
});

confirmInvestBtn.addEventListener('click', () => {
    const amount = parseFloat(amountInput.value);
    if (amount > 0) {
        const balance = parseFloat(localStorage.getItem('balance'));
        if (amount <= balance) {
            localStorage.setItem('balance', (balance - amount).toString());
            let dailyReturn = amount * 0.05;
            let investmentInfo = `You invested ${amount} and will receive ${dailyReturn} daily for 30 days.`;
            investmentResult.textContent = investmentInfo;
            investmentResult.style.display = 'block';
            for (let i = 1; i <= 7; i++) {
                setTimeout(() => {
                    balance = parseFloat(localStorage.getItem('balance'));
                    localStorage.setItem('balance', (balance + dailyReturn).toString());
                    investmentResult.textContent += `\nDay ${i}: You received ${dailyReturn}. New balance: ${localStorage.getItem('balance')}`;
                }, i * 24 * 60 * 60 * 1000); // 24 hours in milliseconds
            }
        } else {
            alert('Insufficient balance!');
        }
    }
});
