const balanceSpan = document.getElementById('balance');
const usernameSpan = document.getElementById('username');
const toggleBalanceIcon = document.getElementById('toggle-balance-icon');
const balanceContainer = document.getElementById('balance-container');
const withdrawBtn = document.getElementById('withdraw-btn');
const depositBtn = document.getElementById('deposit-btn');
const investBtn = document.getElementById('invest-btn');

usernameSpan.textContent = localStorage.getItem('username');
const balance = localStorage.getItem('balance');
balanceSpan.textContent = balance ? balance : '0.00';

toggleBalanceIcon.addEventListener('click', () => {
    if (balanceContainer.style.display === 'none' || balanceContainer.style.display === '') {
        balanceContainer.style.display = 'block';
        toggleBalanceIcon.classList.remove('fa-eye-slash');
        toggleBalanceIcon.classList.add('fa-eye');
    } else {
        balanceContainer.style.display = 'none';
        toggleBalanceIcon.classList.remove('fa-eye');
        toggleBalanceIcon.classList.add('fa-eye-slash');
    }
});

withdrawBtn.addEventListener('click', () => {
    window.location.href = 'withdraw.html';
});

depositBtn.addEventListener('click', () => {
    window.location.href = 'deposit.html';
});

investBtn.addEventListener('click', () => {
    window.location.href = 'invest.html';
});
