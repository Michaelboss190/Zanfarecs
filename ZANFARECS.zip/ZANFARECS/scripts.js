
document.addEventListener('DOMContentLoaded', () => {
  const loginSignupForm = document.getElementById('login-signup-form');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const signupBtn = document.getElementById('signup-btn');
  const loginBtn = document.getElementById('login-btn');
  const loader = document.getElementById('loader');

  loginSignupForm.addEventListener('submit', (e) => {
    e.preventDefault();
  });

  signupBtn.addEventListener('click', async () => {
    const username = usernameInput.value;
    const password = passwordInput.value;
    if (username && password) {
      try {
        const response = await fetch('/api/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        });
        const data = await response.json();
        alert(data.message);
        if (data.success) {
          localStorage.setItem('username', username);
          localStorage.setItem('password', password);
          localStorage.setItem('isLoggedIn', 'true');
          window.location.href = 'dashboard.html';
        }
      } catch (error) {
        console.error(error);
      }
    } else {
      alert('Please fill in all fields!');
    }
  });

  loginBtn.addEventListener('click', async () => {
    loader.style.display = 'block';
    const username = usernameInput.value;
    const password = passwordInput.value;
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await response.json();
      alert(data.message);
      if (data.success) {
        localStorage.setItem('isLoggedIn', 'true');
        setTimeout(() => {
          loader.style.display = 'none';
          window.location.href = 'dashboard.html';
        }, 2000);
      } else {
        setTimeout(() => {
          loader.style.display = 'none';
        }, 2000);
      }
    } catch (error) {
      console.error(error);
    }
  });

  // Check if user is already logged in
  if (localStorage.getItem('isLoggedIn') === 'true') {
    window.location.href = 'dashboard.html';
  }
});
