
const withdrawalForm = document.getElementById('withdrawal-form');
const amountInput = document.getElementById('amount');
const dashboardBalance = parseFloat(localStorage.getItem('balance'));

console.log('Dashboard Balance:', dashboardBalance);

withdrawalForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const amount = parseFloat(amountInput.value);
    console.log('Withdrawal Amount:', amount);

    if (amount > dashboardBalance) {
        alert(`Insufficient balance. You have $${dashboardBalance} available.`);
    } else if (amount <= 0) {
        alert('Please enter a valid amount.');
    } else {
        const newBalance = dashboardBalance - amount;
        localStorage.setItem('balance', newBalance.toString());
        window.location.href = 'dashboard.html';
    }
});
