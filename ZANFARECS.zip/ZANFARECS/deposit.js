const depositForm = document.getElementById('deposit-form');
const amountInput = document.getElementById('amount');
const nextBtn = document.getElementById('next-btn');
const bankDetails = document.getElementById('bank-details');
const doneBtn = document.getElementById('done-btn');

nextBtn.addEventListener('click', (e) => {
    e.preventDefault(); // Prevent form submission
    bankDetails.style.display = 'block';
    depositForm.style.display = 'none';
});

doneBtn.addEventListener('click', () => {
    const amount = parseFloat(amountInput.value);
    const currentBalance = parseFloat(localStorage.getItem('balance') || '0');
    const newBalance = currentBalance + amount;
    localStorage.setItem('balance', newBalance.toString());
    window.location.href = 'dashboard.html';
    window.location.reload(); // Reload the dashboard page to update the balance
});