
const getStartedBtn = document.getElementById('get-started-btn');

getStartedBtn.addEventListener('click', () => {
    window.location.href = 'login-signup.html';
});
